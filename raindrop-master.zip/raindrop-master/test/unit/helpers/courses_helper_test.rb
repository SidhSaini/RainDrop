require 'test_helper'

class CoursesHelperTest < ActionView::TestCase
end
